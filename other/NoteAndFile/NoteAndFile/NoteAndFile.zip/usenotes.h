#pragma once
#ifndef USENOTES
#define USENOTES



#endif // !USENOTES
