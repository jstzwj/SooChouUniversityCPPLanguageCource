#pragma once
#ifndef VERSION
#define VERSION

#define VERSION "1.0.0"
#define MAJOR_VERSION 1
#define MINOR_VERSION 0


#define PUBLIC_MEMBER
#define PRIVATE_MEMBER
#define STRUCT_STATIC
typedef unsigned char bool;
#define true 1
#define false 0
#endif // !VERSION
